from django.shortcuts import render, redirect
from .forms import TeamsForm
from .models import Player
import csv
import pandas as pd

# Create your views here.


def Display(request, team1, team2):
    topPlayers = Player.objects.filter(TeamName__in=[team1, team2])
    topPlayers = topPlayers.order_by("FantasyPoints")[:11]
    context = {
        "players": topPlayers,
    }
    return render(request, "template.html", context)

def LoadCSV(request):
  data = pd.read_csv('merged_data_for_janhavi.csv', sep=',')
  for i in range(len(data)):
    player = Player(Name=data.iloc[i][2], TeamName=data.iloc[i][1], FantasyPoints=float(data.iloc[i][3]))
    player.save()
  return render(request, "dataload.html", {"players": Player.objects.all()})

def Menu(request):
    form = TeamsForm(request.POST or None)
    message = None
    if request.POST:
        if form.is_valid():
            team1 = form.cleaned_data["Team1"]
            team2 = form.cleaned_data["Team2"]
            return redirect("recommend", team1=team1, team2=team2)
        else: message = form.errors
    else:
        form = TeamsForm(None)
        return render(request, "menu.html", {"form": form})
    context = {
        "form": form,
        "msg" : message,
    }
    return render(request, "menu.html", context)
